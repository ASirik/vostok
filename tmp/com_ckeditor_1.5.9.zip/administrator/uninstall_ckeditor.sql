DELETE FROM #__plugins WHERE element = 'ckeditor' AND name = 'Editor - CKEditor';
